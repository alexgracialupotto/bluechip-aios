---
name: onboard
description: Use on Day 1 of an AIOS install, when someone says "set me up", "onboard me", "let's get started", "fill in my AIOS", or has just cloned the kit. Combined wizard — runs a bounded grill across 7 coverage areas AND scaffolds the Day-1 file set at the end. Idempotent — re-run any time after editing aios-intake.md.
---

## What this skill does

Single combined wizard. Reads or writes `aios-intake.md` (the canonical intake), conducts a **bounded grill** across 7 coverage areas if the file isn't filled, scaffolds the Day-1 file set, then ingests the intake into the installee's own `wiki/`. No separate `/scaffold-from-intake` skill — this is one flow.

**This is the only entry point an installee needs to know.** `/grill-me` stays a separate general-purpose skill for plans, positioning, and strategy sessions — don't send a Day-1 user there.

**The wow moment:** at the end, suggest the closing prompt *"Try this — ask me: what should I focus on this week?"* The user runs it once. That's the wow. There's no `/today` skill to save — the prompt itself teaches the habit of asking the system first.

## When NOT to run this

- If the user has already onboarded and wants to refresh: still run, but skip questions already answered (idempotent).
- If the user wants to add a new connection: that's not onboarding — point them at `connections.md` to edit directly.

## Execution

### Step 1: Read the intake

Read `aios-intake.md`. Check which Q1-Q7 sections have content vs. `[Your answer here]` placeholders.

- **All filled** → skip Step 2, jump to Step 3 (scaffold).
- **Some filled** → ask the user: "I see Q1, Q3, Q4 are answered. Want to fill the rest now, or scaffold from what's there?" Their call.
- **None filled (fresh clone)** → run Step 2 as a bounded grill.

### Step 2: The bounded grill (7 coverage areas)

**Method — grill mechanics, install-grade bound:**

- **One question at a time.** Never batch. Never present all seven up front as a form.
- **Pre-fill your recommended answer.** Before asking, infer what you can from anything already on disk — a README, a website they mention, an earlier answer — and offer it: *"My read is X. Confirm, correct, or redirect."* Confirming is faster than composing, and it shows the system already thinks.
- **Checkpoint after EVERY answer, before asking the next.** Append it to `aios-intake.md` immediately. The file is the source of truth, not your context. A session that dies at Q5 must lose nothing. Never make the user ask you to save.
- **Bound the depth.** Q1–Q6 are one pass. Ask a follow-up only when an answer is unusable as written (vague, or it contradicts an earlier one) — don't hunt for depth you don't need. **Q7 is the exception: grill it properly** (see below).
- **Don't stall.** If they can't answer, record it as a flag with an owner and move on.

Target: ~20 minutes to the scaffold. An install that turns into a 45-minute interview before anything gets built feels like homework, not magic — the scaffold *is* the wow, so protect its arrival time.

**Q1 — Who are you, what do you sell, who do you sell it to?**
Identity, offer, ICP. One paragraph each is fine.

**Q2 — Paste 1-2 things you've written recently. Don't edit them.**
*This is the only question with a hard rule.* Voice samples MUST be pasted, not typed mid-conversation. If the user starts typing fresh prose, refuse:

> *"Stop — paste it raw. If you type it here while we're talking, the sample is already shaped by our conversation. Open your last email or LinkedIn post in another tab and paste the unedited text. This is the one rule I can't bend."*

Ask for two samples. One email, one post. Or two of either.

**Q3 — What are your 2-3 biggest priorities for the next 90 days?**
Quarterly priorities. Push back if they say "grow my business" — make them name a number, a deadline, or a deliverable.

**Q4 — Where does revenue actually land, and where is it tracked?**
Multiple answers OK. Map to Tier-1 Domain 1 (Revenue/Financials).

**Q5 — Where do you talk to customers, your team, and the outside world day-to-day?**
Email (Gmail/Outlook), Slack/Teams/Discord, DMs. Map to Domains 2 + 4.

**Q6 — Where do meeting recordings, notes, and important docs live?**
Map to Domains 6 + 7.

**Q7 — What's the one task that eats your week, and where do you currently track work?**
Capture top_pain (it selects the first skill worth building) + Domain 5 (tasks).

**Grill this one properly — it's the highest-leverage answer in the intake.** `top_pain` decides which tool they wire on Day 2 and which skill they build first. "Email takes forever" is not an answer you can build from; it produces a generic first skill and the install falls flat a week later. Keep pulling until you have a concrete, repeated, observable task. Typical thread:

1. Walk me through the last time you did it — actual steps, in order.
2. How often, and how long each time?
3. Where does the input arrive, and where does the output have to land?
4. Which step is judgment, and which is just moving data? (Only the second half is automatable on Day 2 — be honest about the split.)
5. What breaks when you skip it?

Stop when you could write the SOP yourself. Capture it in **their words**, not your paraphrase. This is the one place where more questions beat fewer.

Domain 3 (Calendar) is auto-inferred from Q5: Gmail → Google Cal; Outlook → Outlook Cal. Confirm in Step 3.

### Step 3: Scaffold the Day-1 file set

Once the intake is complete, generate these files (or update if re-running). Back up originals to `archives/intake-{YYYY-MM-DD-HHMM}/` if any exist.

1. **`context/about-me.md`** — from Q1 (identity, role) + Q7 (top_pain). One short paragraph each.
2. **`context/about-business.md`** — from Q1 (offer, ICP) + Q4 (revenue model). One paragraph.
3. **`context/priorities.md`** — from Q3. Numbered list, one line per priority.
4. **`references/voice.md`** — from Q2. Paste samples verbatim with a short header explaining their use ("Match this register when drafting; don't fake voice on external content without showing me first").
5. **`connections.md`** — populate the 7-row table from Q4-Q7 answers. Each row gets `mechanism: not yet connected`, `auth: —`, `last checked: —`. The user starts connecting on Day 2, at whichever rung fits them (`references/connecting-tools.md`).
6. **`CLAUDE.md`** — fill all `{{...}}` placeholders. Substitute the user's name, stated priority, voice register summary, and a brief connections summary.

### Step 3.5: Seed their wiki

The scaffold makes the AIOS *work*. This step makes their second brain **non-empty on Day 1**, which is its own wow — they open Obsidian and there's already a graph about their own business.

Run it automatically, no permission prompt. Do it *after* the scaffold, while the interview is still in context.

1. Copy the completed intake to `wiki/raw/{YYYY-MM-DD}-onboarding-{their-name-slug}.md`. Raw sources are immutable — write it once, never edit it later.
2. Run the wiki **INGEST** flow per `wiki/CLAUDE.md` §4. Expect roughly:
   - source page — the onboarding session itself
   - entity pages — them, their company, any client/prospect they named
   - concept pages — their business model, their 90-day priorities, their top pain
3. Update `wiki/index.md` and append to `wiki/log.md`. Both are required by the schema.

**Read `wiki/CLAUDE.md` before writing anything into `wiki/`** and follow its rules exactly — frontmatter on every page, `[[wikilinks]]`, raw sources immutable.

**Skip silently if there's no `wiki/` directory.** The standard kit ships one, so this normally runs; a root-only install shouldn't error out over it.

### Step 4: The closing screen

Print one screen. Three lines max:

```
✓ Day 1 done. Your AIOS knows who you are, what you sell, what matters this quarter, and how you sound — and your wiki has its first pages. Open the graph in Obsidian.

Today: ask me — "what should I focus on this week?"
Tomorrow: export one real file from your business, drop it in this folder, and ask me a question about it. That is rung 1 in references/connecting-tools.md, and it needs nothing installed.
Day 7: reread context/ and check it still describes your business.
```

When the user runs the closing prompt ("what should I focus on this week?"), respond using only the new context files. Hit:
- 3-bullet priority list, in their voice register from Q2
- Each bullet ties back to a stated 90-day priority from Q3
- Final line: *"If I had to pick one thing for Monday, it'd be [X], because [reason from priorities]. Want me to draft the first email? And which part of this could the system take off you?"*

That closing question seeds the habit the whole system runs on: ask what the system could take before doing it by hand.

## Critical implementation rules

1. **7 coverage areas, not 7 questions.** Follow-ups inside an area are encouraged — deeply on Q7, sparingly elsewhere. What's non-negotiable is the *scope*: don't invent an eighth topic, and don't let the interview outgrow the ~20-minute bound. Depth where it pays, never breadth for its own sake.
2. **Checkpoint after every answer.** `aios-intake.md` is written incrementally, never in one batch at the end. If the session dies mid-interview, everything said so far is already on disk.
3. **Voice paste cannot be skipped.** If the user types samples mid-chat, refuse and tell them to paste from real writing.
4. **One-shot scaffold.** After Step 2 ends, write Step 3 files in a single batch. No multi-turn confirmation. The user iterates by editing `aios-intake.md` and re-running.
5. **Idempotent.** Re-running with an edited intake refreshes context files; backs up originals to `archives/intake-{ts}/`. Skips questions already answered unless the user wants to revise. **On a re-run, do NOT re-ingest into `wiki/`** — the original raw source stays immutable. Update the derived pages only if the intake materially changed.
6. **Closing screen is three lines.** Not a menu.
7. **No extra skills generated.** Don't scaffold `/today`, `/draft`, `/connect`, etc. The kit ships 3 skills; the user authors more via `/skill-builder`.
8. **Read-only on `references/operating-loop.md`.** It already ships in the kit. Don't overwrite.
9. **No `.env` writes.** Don't ask for API keys on Day 1. Connections come Day 2.
10. **Never send a Day-1 user to write a script.** The Day-2 instruction is rung 1 of `references/connecting-tools.md`: hand it a real file and ask a real question. Offer rung 2 or 3 only if they have already said they can code, or they ask. Gating the first win behind an API script is how a non-technical installee stalls and never comes back.

## Verification (for the implementer)

- Cold-test: clone a fresh kit, run `/onboard`, answer all 7 areas, scaffold runs, ask the wow prompt, response cites Q1 + Q3 + Q7 specifically. Generic = fail.
- **Crash-safety:** kill the session after the Q3 answer. Expected: `aios-intake.md` already holds Q1–Q3 on disk. Re-running resumes at Q4. Losing anything = fail.
- **Q7 depth:** answer Q7 with "email takes forever" and stop. Expected: the skill pushes for the concrete repeated task and does not move on. Accepting it = fail.
- **Wiki seed:** after a cold run, `wiki/` has a raw source, a source page, an entity page for the installee, `index.md` updated, and a `log.md` entry.
- Idempotency: re-run `/onboard` with one Q3 priority changed. Expected: only `context/priorities.md` and `CLAUDE.md`'s priority section update; backup created in `archives/intake-{ts}/`; **no duplicate raw source in `wiki/raw/`**.
- Voice rejection: type a sample mid-chat. Expected: skill refuses, asks for paste.
- **Timing:** a cold run reaches the scaffold in ~20 min. Materially longer means the grill is unbounded — tighten Q1–Q6.

