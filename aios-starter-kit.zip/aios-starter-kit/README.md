# AIS-OS — AI Operating System starter kit for Claude Code

A free, MIT-licensed starter kit that turns Claude Code into your personal **AI Operating System (AIOS)**. Audience: anyone building automations — solopreneurs, small business operators, managers, creators, AI consultants. Pairs with a companion masterclass video.

The kit personalizes itself to you via an `/onboard` interview, then gives you two recurring thinking skills (`/audit`, `/level-up`) to keep building leverage week over week.

> **AIS-OS** stands for **AI Automation Society OS** — the way Nate designed this AIOS to be set up for members of his community, [AI Automation Society](https://www.skool.com/ai-automation-society). The kit is universal (it works for anyone), but the structure mirrors how AIS members run their own businesses on top of it.

---

## The litmus test

> **"While you're not at your desk, your AIS-OS observes one real-world event and produces an output that's faster and more accurate than what you'd produce yourself."**

Every design decision in this kit rolls up to that test. If a layer, skill, or template doesn't contribute to it, it doesn't ship.

---

## How you'll know it's working

Three felt **success indicators** tell you the AIOS is actually changing how you work. Not KPIs — there's no objective metric. These are lived experiences that show up in your week.

**1. Team-reaches-out:**

> *"A teammate messages you with a question. You realize your AIOS would answer it better, faster, and with exact sources — even if you were awake and free. So you ask your AIOS too. That's the moment you stop being a bottleneck for your own knowledge."*

**2. Context-switching reduction:**

> *"You stop opening new tabs. You stop launching the desktop app. When something new lands, your first move is to ask the AIOS, not to open six things. The default surface for thought work shifts. Silent. Compounding."*

**3. Knowledge-leaves-your-head:**

> *"You stop trying to remember business facts. You don't rehearse what you decided last quarter or what your customer said in that meeting. You trust the retrieval. The AIOS holds the truth, you hold the questions."*

**Personal foundation → company AI-readiness.** Once these indicators show up for one person, the same data architecture powers everything else. Custom dashboards on the data you already collect. Automations on top of the connections you already wired. Team rollout where everyone has theirs. *A company where every operator runs a personal AIOS is a company that's actually AI-ready.*

The kit teaches personal AIOS first. Everything scales from there.

---

## Two frameworks

The kit teaches two complementary frameworks. **Three Ms first, Four Cs second.** Without the brain rewire, the architecture is just a folder structure.

### The Three Ms — operator brain (how you think)

| M | One-liner |
|---|---|
| **Mindset** | Default Shift, Function Breakdown, Curiosity Rule. *To what extent can AI be leveraged here?* |
| **Method** | Find Constraint → EAD (Eliminate, Automate, Delegate) → Map Process → Pick Autonomy Level → Tie to KPI. |
| **Machine** | Lego Principle, Validation Chain, Bike Method, Intern Rule, Kill Switch. *Boring is beautiful. Workflows beat agents.* |

Full breakdown in `references/3ms-framework.md`. The `/level-up` skill walks you through all three weekly.

> *The Three Ms of AI™ is a trademark of Nate Herk. © 2026 Nate Herk.*

### The Four Cs — architecture (what you build)

| # | Layer | One-liner | "This layer is in place" test |
|---|---|---|---|
| 1 | **Context** | Knows your business | Fresh Claude session answers "what does this business do and who works here?" without browsing |
| 2 | **Connections** | Reaches your stuff | "What's on my calendar tomorrow and what tasks are due?" → live data, no paste |
| 3 | **Capabilities** | Knows how to do the work | A short phrase triggers a multi-step workflow that produces an artifact |
| 4 | **Cadence** | Runs without being asked | Laptop closed. A brief lands in the inbox. A teammate messages it and gets a real answer |

**Brand line:** Context. Connections. Capabilities. Cadence.

> *The Four Cs of an AIOS™ is a trademark of Nate Herk. © 2026 Nate Herk.*

Dependency graph: Context is non-skippable. Connections + Capabilities can build in parallel. Cadence is last — don't automate workflows that don't work manually.

---

## What ships — 5 skills

The kit is intentionally lean. Skills here are ideation prompts and thinking tools, not heavy automations. You hack on top of the structure.

| Skill | Type | When to run |
|---|---|---|
| `/onboard` | Setup wizard (one-time) | Day 1, right after you unzip. A bounded interview about your business, then it writes your Day-1 files, fills `CLAUDE.md`, and seeds your wiki. |
| `/audit` | Recurring thinking skill | Day 7, then weekly. Four-Cs gap report. Read-only. Watch the score climb. |
| `/level-up` | Recurring thinking skill | Day 14, then weekly. Three Ms interview (Mindset → Method → Machine). One run = one shipped artifact. |
| `/grill-me` | On demand | Any time you need to think something through — a plan, a pitch, a decision. Interviews you hard and checkpoints every answer to a file, so nothing is lost when the session ends. |
| `/skill-builder` | On demand | Turn a process you already do well into a repeatable skill. **This is how your own expertise becomes executable** — the highest-leverage thing in the kit. |

`/audit` asks *"is the AIOS built right?"* (form). `/level-up` asks *"what business leverage am I missing?"* (function). They work in series — fix structure first, then capability planning becomes meaningful.

---

## Setup — 5 steps, about 15 minutes

You need two things installed and one folder on your machine. Then your AIOS interviews you and builds itself. No API keys, no cost beyond the Claude plan you already have.

### 1. Install an editor that runs Claude Code
Already have VS Code, Cursor, or another VS Code-based editor? Use it, skip to step 2. Otherwise install [VS Code](https://code.visualstudio.com/) — free, 2 minutes.

### 2. Install the Claude Code extension
In your editor: **Extensions** → search **"Claude Code"** → **Install** → sign in. You'll know it worked when a Claude panel opens and answers you.

### 3. Unzip this kit somewhere you'll find again
`~/Documents/my-aios` is fine. Avoid Downloads — you'll lose it. Then **File → Open Folder** on that folder.

### 4. Start the version history
The step people skip, and the one that makes this yours. In **Terminal → New Terminal**, from inside the folder:

```bash
git init
git add -A
git commit -m "Day 0 — before my AIOS knows anything"
```

From here, every change to your business brain is a reviewable, revertible commit. In a month, `git log` is the record of how much your system learned — the difference between a tool that remembers things and one you own.

> No git? macOS: run `git --version` and accept the prompt. Windows: [git-scm.com](https://git-scm.com/download/win).

### 5. Install Obsidian and open the wiki
[Obsidian](https://obsidian.md/) is free. **Open folder as vault** → select the **`wiki/`** folder inside the kit. Obsidian doesn't do the work, it *shows* it. It'll look nearly empty right now. That's the point — you'll watch it fill.

---

## Now hand it over

In the Claude panel, type **`/onboard`**.

It takes it from here: interviews you about your business, writes your context files, seeds your wiki with the first pages about you. About 15 minutes.

One rule it will hold you to: when it asks for writing samples, **paste real ones** from a sent email or a published post. Don't type fresh prose — a sample written during the conversation is already shaped by the conversation, and your AIOS will learn the wrong voice.

When it finishes, ask it: **"what should I focus on this week?"** That's the first real answer from a system that knows your business.

**Stuck?** Ask Claude in the panel — it can read this README and the whole kit.

---

## Then the rhythm

1. **Use it for a week.** Bring real questions. Make real decisions. Append them to `decisions/log.md`.
2. **Day 7:** run `/audit`. Read the Four-Cs gap report. Pick one gap to close.
3. **Day 14:** run `/level-up`. The Three Ms interview surfaces one automation worth building. Build it.
4. **Week 3+:** weekly `/level-up` ritual. One shipped artifact per week.

---

## Repo layout

```
AIS-OS/
├── README.md
├── CLAUDE.md                        ← Your operating manual (filled by /onboard)
├── EXPANSIONS.md                    ← What to add as you grow
├── LICENSE
├── .gitignore
├── aios-intake.md                   ← Source-of-truth for /onboard. Edit + re-run any time.
├── connections.md                   ← Registry of every system your AIOS can reach
├── context/                         ← About you, your business (filled by /onboard)
├── references/
│   └── 3ms-framework.md             ← The operator brain
├── decisions/
│   └── log.md                       ← Append-only record of what was decided and why
├── archives/                        ← Old stuff. Don't delete. Move here.
└── .claude/
    └── skills/
        ├── onboard/SKILL.md
        ├── audit/SKILL.md
        ├── level-up/SKILL.md
        ├── grill-me/SKILL.md
        └── skill-builder/SKILL.md
├── wiki/                            ← Your second brain (Obsidian-compatible vault)
│   ├── CLAUDE.md                    ← The wiki's own schema & rules — read before touching
│   ├── index.md                     ← Content catalog (what the wiki knows)
│   ├── log.md                       ← Chronological record of every ingest
│   ├── raw/                         ← Immutable source documents (transcripts, articles)
│   └── wiki/                        ← LLM-written pages: sources / entities / concepts / syntheses
```

See `EXPANSIONS.md` for what to add as you grow (`projects/`, `templates/`, `scripts/`, `.claude/agents/`, sub-OS folders, etc.).

---

## The second brain (`wiki/`)

The AIOS root is the **"do"** layer. `wiki/` is the **"know"** layer — a self-maintaining knowledge vault your AIOS writes *as a side effect of working*. Drop in a meeting transcript, an article, or a YouTube transcript and say "ingest this": the AIOS files an immutable copy in `raw/`, writes a summary page, creates/updates pages for every person, company, and concept mentioned, cross-links everything with `[[wikilinks]]`, and updates the index. Nothing you learn dies in a chat again.

### See it visually (optional, 2 minutes)
1. Download [Obsidian](https://obsidian.md) (free).
2. "Open folder as vault" → pick this repo's `wiki/` folder.
3. Open Graph View. It's empty today — every ingest grows the graph. This is your business becoming a map.

The vault ships preconfigured (`.obsidian/` included) so it looks right on first open.

## Your first skill (the real magic)

After `/onboard`, run `/skill-builder` and turn **one of your own methods** into a skill — the framework you teach, your pricing method, your review checklist. That's the moment the AIOS stops being a tool and starts being *your* IP, executable. Skills are files: versionable, improvable, and shareable with your team or community.

---

## License + attribution

MIT License. © 2026 Nate Herk.

The Three Ms of AI™ and The Four Cs of an AIOS™ are trademarks of Nate Herk. Both frameworks ship in this repo with attribution. Use freely; don't repackage as your own.

The companion masterclass video walks you through the kit step by step. Link will land here once it ships.
