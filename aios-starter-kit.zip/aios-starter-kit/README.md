# AIOS Starter Kit

Turn Claude Code into your personal **AI Operating System**: a system that knows your business, reaches your tools, does real work, and remembers everything it learns.

Built by [Bluechip](https://gobluechip.ai) out of how we actually run our own operations. For anyone with a business to run and too much of it in their head: operators, founders, consultants, managers.

The kit interviews you on Day 1 and builds itself around your business. From there you feed it, and it compounds.

---

## The test it has to pass

> **While you are not at your desk, your AIOS observes one real event and produces an output that is faster and more accurate than what you would have produced yourself.**

Every design choice in this kit rolls up to that. If a folder, skill, or template does not serve it, it does not ship.

---

## How it works: the Operating Loop

Four moves, one direction. Knowledge that stops moving is knowledge that rots.

```
Capture  →  Decide  →  Compound  →  Refresh
brainstorms/  decisions/log.md   wiki/     context/
think it      commit to it       file it   keep the brief current
```

| Move | Where it lives | What breaks without it |
|---|---|---|
| **Capture** | `brainstorms/` | Thinking dies with the conversation |
| **Decide** | `decisions/log.md` | You re-litigate the same question every six weeks |
| **Compound** | `wiki/` | Every project starts from zero |
| **Refresh** | `context/` | A fresh session reads a stale brief and answers confidently wrong |

Full framework in `references/operating-loop.md`, including the two parts you will use most:

- **The Repeat Test**: what is worth automating. Count, cost, and shape, with one gate in front of it: what happens if this just stops?
- **The Automation Brief**: five questions that make a candidate buildable: the trigger, the reach, the approval line, the failure mode, the running cost.

Nothing in the kit walks these for you. That is deliberate: the skill that does is the first one worth authoring, and `/skill-builder` exists to help you write it.

---

## What ships: 3 skills

Deliberately lean. These are thinking tools and scaffolds, not heavy automations. You build the heavy things on top.

| Skill | Type | When |
|---|---|---|
| `/onboard` | One-time wizard | Day 1, right after you unzip. A bounded interview about your business, then it writes your context files, fills `CLAUDE.md`, and seeds your wiki. |
| `/grill-me` | On demand | Any time you need to think something through. Interviews you hard and checkpoints every answer to a file, so nothing is lost when the session ends. |
| `/skill-builder` | On demand | Turn a process you already do well into a repeatable skill. **This is how your expertise becomes executable**, the highest-leverage thing in the kit. |

Three tools, no rituals shipped. The kit gives you the method and the means to author skills against your own processes; the recurring rhythm comes from what you build, not from what came in the box.

---

## Setup: about 15 minutes

You need two things installed and one folder on your machine. No API keys, no cost beyond the Claude plan you already have.

> **Using the Claude desktop app (Cowork)? You can skip the editor entirely.** The whole kit runs
> inside Cowork, proven on live installs. Do this instead of steps 1-2:
>
> 1. Unzip the kit somewhere permanent (`~/Documents/my-aios`, not Downloads).
> 2. In the Claude desktop app, start a new **Cowork** task and **add the kit folder**. The
>    folder-attach flow varies between app versions: look for *Add folder* or *Setup project
>    workspace → Project or folder*. When asked about access, choose **Always allow** so it sticks.
> 3. First message, paste exactly: **`please check the folder and install the required skills`**.
>    Skills do not auto-install. Approve each one with **Save** (there is no Save-all yet).
> 4. Check the model selector (top right): pick the most capable model available, not the default.
> 5. Type **`onboard`** to start. ⚠️ In Cowork, type skill names **without the leading slash**:
>    `/onboard` may return "Unknown skill", `onboard` works.
> 6. Step 4 below (git) still applies. Cowork has no terminal, so run those three commands once in
>    your system Terminal from inside the kit folder. Step 5 (Obsidian) applies as-is.
>
> Leave permissions on **manual** for your first session. Switch to auto once you trust what it does.

### 1. Install an editor that runs Claude Code
Already have VS Code, Cursor, or another VS Code-based editor? Use it, skip to step 2. Otherwise install [VS Code](https://code.visualstudio.com/): free, two minutes.

### 2. Install the Claude Code extension
In your editor: **Extensions** → search **"Claude Code"** → **Install** → sign in. You will know it worked when a Claude panel opens and answers you.

### 3. Unzip this kit somewhere you will find again
`~/Documents/my-aios` is fine. Avoid Downloads, you will lose it. Then **File → Open Folder** on that folder.

### 4. Start the version history
The step people skip, and the one that makes this yours. In **Terminal → New Terminal**, from inside the folder:

```bash
git init
git add -A
git commit -m "Day 0, before my AIOS knows anything"
```

From here every change to your business brain is a reviewable, revertible commit. In a month, `git log` is the record of how much your system learned: the difference between a tool that remembers things and one you own.

> No git? macOS: run `git --version` and accept the prompt. Windows: [git-scm.com](https://git-scm.com/download/win).

### 5. Install Obsidian and open the wiki
[Obsidian](https://obsidian.md/) is free. **Open folder as vault** → select the **`wiki/`** folder inside the kit (one level deeper than the kit root). Obsidian does not do the work, it *shows* it. It will look nearly empty right now. That is the point: you will watch it fill.

---

## Now hand it over

In the Claude panel, type **`/onboard`**.

It takes over from there: interviews you about your business, writes your context files, seeds your wiki with the first pages about you. About 15 minutes.

One rule it will hold you to. When it asks for writing samples, **paste real ones** from a sent email or a published post. Do not type fresh prose. A sample written during the conversation is already shaped by the conversation, and your AIOS will learn the wrong voice.

When it finishes, ask it: **"what should I focus on this week?"** That is the first real answer from a system that knows your business.

**Stuck?** Ask Claude in the panel. It can read this README and the whole kit.

---

## Then the rhythm

1. **Use it for a week.** Bring real questions. Make real decisions. Append them to `decisions/log.md`.
2. **Day 7:** reread `context/`. Does it still describe your business? If not, that is your first open loop.
3. **Day 14:** take the task you have done most by hand this fortnight, run it through the Repeat Test, and scope it with the Automation Brief.
4. **Week 3+:** author it with `/skill-builder`. One shipped artifact per week is the pace to hold.

---

## Troubleshooting the first run

Field notes from real installs. Check here before assuming something is broken:

- **"Unknown skill" when typing `/onboard` or `/grill-me` (Cowork):** drop the leading slash, type `onboard`, `grill-me`. The editor extension accepts both.
- **Skills do not appear at all:** they do not auto-install from the folder. Prompt: *"please check the folder and install the required skills"*, then **Save** each one.
- **Your folder-attach screen does not match the instructions:** the Cowork UI changes between versions. The goal is always the same, the kit folder attached to the session with **Always allow** access.
- **Obsidian shows the wrong thing:** use **File → Open folder as vault** and pick the **`wiki/` folder inside the kit**, one level deeper than the kit root. The kit root shows clutter, `wiki/` shows the brain.
- **Answers feel shallow:** check the model selector, you may be on the smaller default model.
- **A long ingest seems stuck:** it is usually batching around rate limits and will report progress if you ask *"what's going on?"*. Asking does not interrupt it. You can open a second session in parallel; jobs continue in the background.
- **Connecting your tools:** prefer each tool's **official API with a scoped key** over catch-all integrations where you can, so you control exactly which endpoints it touches. Keys live in `.env` (gitignored). Some tools have **no official API** at all, and there the honest options are browser automation or manual export. Plan around it.

---

## The second brain (`wiki/`)

The AIOS root is the **do** layer. `wiki/` is the **know** layer: a knowledge vault your AIOS writes as a side effect of working.

Drop in a meeting transcript, an article, or a thread and say "ingest this". It files an immutable copy in `raw/`, writes a summary page, creates or updates a page for every person, company, and concept mentioned, cross-links everything with `[[wikilinks]]`, and updates the index. Nothing you learn dies in a chat again.

The part that turns it from an archive into an asset is `wiki/wiki/syntheses/`: pages that conclude something across several sources. If sources are piling up and syntheses is empty, the wiki is only being written to, never concluded from.

The vault ships preconfigured (`.obsidian/` included) so it looks right on first open. Rules and schema: `wiki/CLAUDE.md`.

---

## Your first skill

After `/onboard`, run `/skill-builder` and turn **one of your own methods** into a skill: the framework you teach, your pricing method, your review checklist, the way you scope a project.

That is the moment the AIOS stops being a tool and becomes your own IP, executable. Skills are plain files: versionable, improvable, and shareable with your team.

---

## Repo layout

```
aios-starter-kit/
├── README.md
├── CLAUDE.md                        ← Your operating manual (filled by /onboard)
├── EXPANSIONS.md                    ← What to add as you grow
├── .gitignore
├── aios-intake.md                   ← Source of truth for /onboard. Edit + re-run any time.
├── connections.md                   ← Registry of every system your AIOS can reach
├── context/                         ← About you, your business, your priorities
├── references/
│   └── operating-loop.md            ← The framework
├── decisions/
│   └── log.md                       ← Append-only record of what was decided and why
├── archives/                        ← Old stuff. Don't delete. Move here.
├── .claude/
│   └── skills/
│       ├── onboard/SKILL.md
│       ├── grill-me/SKILL.md
│       └── skill-builder/SKILL.md
└── wiki/                            ← Your second brain (Obsidian vault)
    ├── CLAUDE.md                    ← The wiki's schema and rules. Read before touching.
    ├── index.md                     ← What the wiki knows
    ├── log.md                       ← Every ingest, chronologically
    ├── raw/                         ← Immutable source documents
    └── wiki/                        ← Written pages: sources / entities / concepts / syntheses
```

See `EXPANSIONS.md` for what to add as you grow: `projects/`, `templates/`, `scripts/`, `.claude/agents/`, sub-OS folders.

---

© 2026 GoBluechip S.L. Released under the MIT License: see `LICENSE`. Yours to use, modify and build on.
