# Index

Content catalog of the wiki. Read this first when answering a query, then drill into pages.
Updated on every ingest. See `CLAUDE.md` for rules, `log.md` for chronology.

**Counts:** 0 sources · 0 entities · 0 concepts · 0 syntheses

---

## Sources
_(none yet — ingest your first document, meeting transcript, or article)_

## Entities
_(none yet — your company will be the seed entity)_

## Concepts
_(none yet)_

## Syntheses
_(none yet — filed when a good query answer is worth keeping)_
