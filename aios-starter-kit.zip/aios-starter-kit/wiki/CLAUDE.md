# CLAUDE.md — LLM Wiki Schema & Operating Rules

This vault is a **persistent second brain** maintained by an LLM (you). The human (you)
curates sources and asks questions; **you** do all reading, summarizing, cross-referencing,
filing, and bookkeeping. The wiki is a compounding artifact — it gets richer with every
source and every question. Follow these rules in **every** interaction.

---

## 1. Three layers

1. **Raw sources** (`raw/`) — immutable source documents. You READ these, you NEVER edit them.
   This is the source of truth. Images go in `raw/assets/`.
2. **The wiki** (`wiki/`) — LLM-generated, interlinked markdown. You own this layer entirely.
3. **The schema** (`CLAUDE.md`, this file) — how the wiki is structured and how you operate.
   Co-evolved with the owner over time. When a convention changes, update this file.

Navigation files live at vault root: `index.md` (content catalog) and `log.md` (chronological).

---

## 2. Folder conventions

```
/                      vault root
├── CLAUDE.md          ← this schema (rules)
├── index.md           ← content catalog, organized by category
├── log.md             ← append-only chronological record
├── raw/               ← immutable source documents
│   └── assets/        ← downloaded images / attachments
└── wiki/
    ├── sources/       ← one summary page per ingested source
    ├── entities/      ← people, companies, clients, products, tools (proper nouns)
    ├── concepts/      ← topics, frameworks, ideas, processes (common nouns)
    └── syntheses/     ← cross-cutting analyses, comparisons, theses, query outputs
```

**File naming:** `kebab-case.md`. Entities/concepts named by their slug (`acme-corp.md`,
`setup-fee-plus-subscription-model.md`). Source pages mirror the raw filename's slug.
Raw sources are prefixed with ISO date: `raw/2026-06-22-some-article.md`.

---

## 3. Page format

Every wiki page starts with YAML frontmatter, then a title, then body. Example:

```markdown
---
type: entity            # entity | concept | source | synthesis
tags: [client, automotive]
created: 2026-06-22
updated: 2026-06-22
sources: 1              # how many raw sources feed this page
status: stable          # stub | active | stable
---

# Page Title

Body in clear prose. Link liberally with [[other-page-slug]].
```

**Body conventions:**
- Open with a one-sentence definition/summary (used by `index.md`).
- Use `[[wikilink]]` (Obsidian basename links) for every entity/concept you mention that
  has — or should have — its own page. A link to a page that doesn't exist yet is fine; it
  marks a stub to create later.
- When a new source **contradicts** an existing claim, do NOT silently overwrite. Add a
  `> ⚠️ Contradiction:` callout noting both claims, their sources, and dates.
- Cite sources inline as `([[source-slug]])` so claims are traceable to `raw/`.
- Keep prose tight. This is a reference work, not an essay.

---

## 4. Operations

**Default style:** **auto-ingest, review after.** Do the full ingest
without stopping to pre-discuss, then report what you created/updated so the owner can correct it.
Ingest one source at a time unless he asks to batch.

### INGEST  (trigger: "ingest X", or the owner drops a file in `raw/` and says process it)
1. Read the raw source in full (read text first; if it references images in `raw/assets/`,
   view them separately for extra context).
2. Write/overwrite the **source page** in `wiki/sources/` (summary, key points, entities &
   concepts touched, link back to the `raw/` file).
3. Create or update every relevant **entity** and **concept** page. A single source may
   touch 10–15 pages — that's expected. Create stubs for new entities/concepts mentioned.
4. Flag contradictions against existing pages (see §3).
5. Update `index.md` (add/refresh catalog entries).
6. Append an entry to `log.md` (see §5 format).
7. **Review checkpoint:** report back what pages were created vs. updated so the owner can correct.

### QUERY  (trigger: the owner asks a question)
1. Read `index.md` first to locate relevant pages, then drill into them. Use search if needed.
2. Synthesize an answer **with citations** (`[[page]]` / `([[source]])`).
3. Offer to **file good answers back** into `wiki/syntheses/` as a new page — comparisons,
   analyses, discovered connections shouldn't vanish into chat history. If filed, update
   `index.md` and `log.md`.

### LINT  (trigger: "lint" / "health-check the wiki")
Scan for and report: contradictions between pages, stale claims superseded by newer sources,
orphan pages (no inbound links), concepts mentioned but lacking a page, missing
cross-references, and data gaps fillable by a web search. Suggest new questions to investigate
and new sources to find. Append a `lint` entry to `log.md`. Only make edits the owner approves.

---

## 5. index.md and log.md

**`index.md` is content-oriented** — a catalog of every page, grouped by category
(Sources / Entities / Concepts / Syntheses), each as `- [[slug]] — one-line summary`.
Update it on **every** ingest and whenever a synthesis is filed.

**`log.md` is chronological & append-only.** Every entry starts with a consistent prefix so
it's greppable:

```
## [2026-06-22] ingest | Source Title
- pages touched: ...
```

Prefix forms: `ingest`, `query`, `lint`, `schema`. Newest entries at the bottom.
`grep "^## \[" log.md | tail -5` shows recent activity.

---

## 6. Working principles

- **You write the wiki; the owner never has to.** Their job is sourcing, direction, and questions.
- **Bookkeeping is the whole point.** Never skip an index or log update. Never leave a
  cross-reference dangling on the inbound side.
- **Don't re-derive — accumulate.** Build on existing pages instead of restating from scratch.
- **Stay traceable.** Every non-obvious claim links to the source that supports it.
- **Surface, don't bury.** Contradictions and stale data get flagged, not overwritten.
- This vault is a git-friendly pile of markdown. Prefer many small linked pages over few large ones.

---

## 7. Context: who this is for

{{Your Name}} — {{filled by /onboard: role, business, domains}}. Domains likely to accumulate
here: clients & prospects, your business model, internal SOPs/systems, sales pipeline,
AI/automation techniques, and personal strategy. Seed entity for the wiki is your own company —
create it as the first entity page on your first ingest.

**This vault is the "know" layer of your AIOS.** The parent repo (`../`, governed by
`../CLAUDE.md`) is the "do" layer — live ops, decisions, tool connections, weekly automation.
Rule of thumb: action-this-week lives in the AIOS; durable, sourced knowledge lives here. The
AIOS routes research, meeting intelligence, and learnings into this vault and queries it for
depth. When a fact appears both here and in the AIOS's `../context/` and they diverge, **this
vault is the researched source of truth** — flag the drift, don't silently overwrite.
