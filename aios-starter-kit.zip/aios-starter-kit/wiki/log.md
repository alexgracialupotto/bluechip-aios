# Log

Append-only chronological record. Newest at the bottom. Prefixes: `ingest` · `query` · `lint` · `schema`.
Tip: `grep "^## \[" log.md | tail -5` shows recent activity.

---

_(empty — your first ingest writes the first entry)_
