# Connecting your tools

Your AIOS is only as useful as what it can see. This is how it starts seeing your real business, in three rungs.

**Climb the lowest rung that works today.** Rung 1 needs nothing installed and takes five minutes. Most people should start there, including people who could do rung 3. A system that sees one real thing today beats a perfect integration you finish next month.

---

## Rung 1: hand it the file (no setup, 5 minutes)

Your AIOS reads any file you put in its folder. That is already a connection, and for most first wins it is the only one you need.

1. Export or download **one real thing** from the business. Last month's sales export, a bank statement CSV, a signed contract, a meeting transcript, a long email thread you paste into a text file.
2. Drop it in the kit folder. `archives/` is fine, or make a folder that means something to you.
3. Ask a real question about it. Not "summarise this". Something you would otherwise have worked out by hand:
   - "Which of these customers have not ordered in 90 days?"
   - "What did I agree to in this contract that I might have forgotten?"
   - "Pull every commitment I made on this call, with who owns it."
4. **Then say "ingest this".** This is the step that makes it compound instead of evaporating: an immutable copy goes to `wiki/raw/`, a summary page gets written, and every person, company and concept mentioned gets its own linked page. Ask the same question in three weeks and it answers from everything you have fed it since.

Step 4 is the one that matters. Steps 1 to 3 give you an answer; step 4 gives you a system. **The single biggest difference between a valuable wiki and an empty one is how much got ingested, not how many tools got wired.**

That is the whole product, working, on day two. Everything below is about removing the copy-paste step, which is a convenience, not the value.

**When to stay on rung 1:** the data changes monthly rather than daily, or an export takes you under a minute. Automating a one-minute monthly task fails the Repeat Test. See `references/operating-loop.md`.

---

## Rung 2: connect an app (no code, 15 to 30 minutes)

For tools with a ready-made connector, your AIOS can read them directly, with no script and no API keys in a file.

1. Open the connectors or MCP settings in your Claude client and look for the tool by name. Gmail, Google Drive, Calendar, Slack, Notion and similar are commonly available.
2. Sign in when it asks. The client stores the credential; you do not paste a key anywhere.
3. Test it with a question only that tool can answer: "what is on my calendar Thursday?" If it answers, it is connected.
4. Add the row to `connections.md` with `mechanism: mcp` and today's date.

**If the tool you need is not in the list, stop.** Do not jump to rung 3 out of stubbornness. Go back to rung 1 for that tool and spend the time on a different part of the business.

---

## Rung 3: write a small script (code, an afternoon)

Only when the tool has no connector, the data matters weekly or more often, and the export is genuinely painful.

1. Find the API docs. Get one call working in isolation before wiring anything.
2. Put the key in `.env`. Never in a file you commit. Check `.gitignore` covers it.
3. Write the script under `scripts/`.
4. **Save `references/{tool}-api.md`** while it is fresh: endpoints, auth flow, the queries you actually use. Researched once, saved forever. Skipping this is the single most common regret, because six weeks later you will re-read the API from scratch.
5. Add the row to `connections.md` with `mechanism: script`.

---

## Which rung is this tool on?

| If... | Rung |
|---|---|
| You can export it in under a minute, or it changes monthly | 1, and stay there |
| There is a connector with the tool's name on it | 2 |
| No connector, and you touch the data weekly or more | 3 |
| No connector, and you touch it monthly | 1 |
| It holds client data and you are not sure you are allowed | **Stop.** Ask whoever owns that policy first |

## The honest part

Most people wire two or three tools, ever, and get most of the value from the first one. The goal is not a full `connections.md`. It is that the question you ask most often has a real answer behind it.

An entry in `connections.md` that no longer works is worse than no entry, because you will trust an answer built on stale data. If something breaks, mark it broken the same day.
