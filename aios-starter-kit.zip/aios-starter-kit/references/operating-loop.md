# The Operating Loop

The operator framework this kit runs on. Read it once. It is not theory: every folder in this repo and every skill in `.claude/skills/` exists to serve one of the four moves below.

Most people who install an AI system get a better chat window. The difference between a chat window and an operating system is not the model. It is whether anything you learn on Tuesday is still working for you in November. That is what the loop is for.

---

## Part 1. The loop: how knowledge moves

Four moves, one direction. Knowledge that stops moving is knowledge that rots.

```
Capture  →  Decide  →  Compound  →  Refresh
brainstorms/  decisions/log.md   wiki/     context/
think it      commit to it       file it   keep the brief current
```

### 1. Capture: get it out of your head

Thinking that lives only in a conversation dies with the conversation. Capture means it lands in a file while you are still thinking, not after.

- The unit is a **session file**, not a note. One topic, one file, dated.
- Checkpoint as you go. A session that dies mid-thought should still have everything said so far on disk.
- Raw stays raw. A transcript, an email thread, a voice memo: keep the original untouched and write your interpretation next to it, never on top of it.

The skill: `/grill-me`.

### 2. Decide: commit to it, with the why

A capture that never becomes a decision is an open loop. Open loops are the single largest source of repeated work: you re-litigate the same question every six weeks because nothing recorded that you already answered it.

A decision entry carries four things:

| Field | Why it earns its place |
|---|---|
| **Decision** | What you actually chose, in one sentence. |
| **Why** | The reasoning *and* what would change your mind. This is the part future-you needs. |
| **Alternatives considered** | What you rejected and on what grounds. Stops the same options coming back. |
| **Owner** | Who is accountable. A decision with no owner is a preference. |

The file is append-only. You do not edit history; you supersede it with a later entry.

The file: `decisions/log.md`.

### 3. Compound: file it where it accrues

The wiki is the layer that makes this an asset instead of an archive. It holds the durable, sourced version of what you know: clients, people, competitors, concepts, meetings, the things that stay true after this quarter ends.

Two failure modes to watch for, both silent:

- **Write-only.** Sources pile up and nothing is ever concluded from them. If you have six sources pointing the same direction and no synthesis page, the wiki is a filing cabinet, not a brain. Write the synthesis.
- **Unsourced.** A page that asserts something with no citation is a rumour with formatting. Every claim traces back to a raw source.

The rules live in `wiki/CLAUDE.md`. Read them before touching the vault.

### 4. Refresh: keep the live brief current

`context/` is the one-page answer to "who am I and what matters right now." It is what a fresh session reads before it does anything else. It is also the layer that goes stale fastest, because nothing breaks when it does. You just start getting confidently outdated answers.

The rule: when the wiki learns something that changes the one-page answer, change the one-page answer. When `context/` and the wiki disagree, the wiki is the researched source of truth, and the disagreement itself is worth saying out loud.

**The loop test:** pick any belief your system acts on. Can you trace it back through refresh → compound → decide → capture to a real source? If not, you are running on vibes with extra steps.

---

## Part 2. The Repeat Test: deciding what to build

You will have more automation ideas than build time, permanently. The Repeat Test is how you rank them without a meeting.

Before anything else, one gate:

> **The drop question: what happens if this just stops?**
>
> If the honest answer is "nothing", you are done. Deleting the task beats automating it, every time, and it takes an afternoon instead of a month. Reports nobody reads, approval steps nobody uses, statuses nobody checks: kill them. Automating waste industrialises it.

If it survives the drop question, score it on three numbers. Get the actual numbers, not impressions.

| | Question | What good looks like |
|---|---|---|
| **Count** | How many times did you do this in the last 30 days? | 4+ |
| **Cost** | Minutes per run × count = the monthly bill, in hours. | 2h+/month |
| **Shape** | Are the steps the same every time? | **Fixed** |

**Shape** is the one people get wrong, so name it explicitly:

- **Fixed**: same steps, same order, decisions follow rules you can write down. Build it. This is where automation actually pays.
- **Bent**: same steps, but a judgement call sits in the middle. Build the parts around the judgement, and keep yourself in the middle. This is most real work.
- **Loose**: different every time; the shape *is* the thinking. Do not automate it. Write down how you do it instead, and the writing itself is the leverage.

**The ranking rule:** high bill × fixed shape wins. A two-hour-a-month task with a fixed shape beats a ten-hour-a-month task that is loose, because the first one ships this week and the second one becomes a project that quietly dies.

**One per cycle.** One scoped, shipped, actually-used automation per week beats five specced ones. The failure mode of every system like this is a folder of half-built ideas.

---

## Part 3. The Automation Brief: scoping one

Five questions. If you cannot answer all five, you are not ready to build. That is a useful result, not a failure: the unanswerable question is exactly what to go find out.

**1. The trigger: what starts it, and how does the system see that start?**

"When a client emails" is not a trigger until you can say how the system knows an email arrived. Every automation is either **event-triggered** (something happened), **time-triggered** (it is Monday), or **you-triggered** (you type a command). You-triggered is a completely respectable answer and the right first version of nearly everything.

**2. The reach: what must it read, what must it write, and can it get there today?**

List every system involved and mark each `read`, `write`, or `both`. Then check honestly whether your AIOS can reach it right now. **Reach before build.** The most common way one of these projects stalls is specifying a workflow across four tools you have not connected. If the reach is not there, the automation is not the next step, the connection is.

**3. The approval line: where does a human stay in it?**

Draw the line explicitly, in writing. On one side the system acts; on the other side you decide.

The default line, and you should need a reason to move it: **anything that leaves your control needs you.** Emails, messages, payments, published content, anything a client sees. The system drafts it, you send it. That single rule is what makes an aggressive AI system safe to run against a real business, and it costs you almost nothing, because writing the draft was the work.

Move the line only after the thing has run a while and been right every time.

**4. The failure mode: how does it break, and who notices?**

Everything you build fails eventually. The question is whether it fails loudly or silently. Silent failure is the expensive one: an automation that quietly stops running, or worse, quietly starts being wrong, while you keep trusting it.

Name the likely failure, name the signal you would see, name who is expected to see it. If the answer to "who notices" is nobody, do not ship it.

**5. The running cost: what does it cost to keep alive?**

Nothing you build is free after launch. Credentials expire, formats change, APIs deprecate, the process itself moves. Estimate the monthly upkeep in minutes before you build, and compare it to the bill from the Repeat Test. If upkeep is not clearly smaller than the bill, you are buying yourself a second job.

Write the answers into `decisions/log.md`. The brief *is* the decision entry.

---

## Part 4. Build rules

Five rules, learned the expensive way.

**1. Smallest thing that works.** Rank your options by how little machinery they need and take the first one that solves the problem: a saved prompt you run by hand, a script with no AI in it at all, a skill with one AI step, and only then something agentic that reasons across tools. Deterministic beats clever. You should have to argue yourself *up* this ladder, never down it.

**2. Don't put AI where rules will do.** If a decision can be expressed as a rule, express it as a rule. AI in the loop is for the steps that genuinely need language or judgement, not for `if amount > 500`. Every AI step you add is a step that can be wrong in a new way each time it runs.

**3. Test each step before chaining.** Verify step one produces the right thing, then add step two. A five-step workflow assembled in one go and run for the first time end-to-end teaches you nothing about which of the five is broken.

**4. Run it manually first, on purpose.** The first version is something you invoke and watch. You are not being cautious, you are collecting the edge cases that nobody thinks of at the whiteboard: the weird client name, the empty attachment, the month with no data. Automate the trigger only after the body has been right several times in a row.

**5. Ship the ugly version.** Real usage tells you what to build next, and it tells you cheaply. Speculative polish is the most expensive way to discover you built the wrong thing.

---

## What "working" looks like

There is no clean metric for this, so use signals instead. You will recognise them when they show up.

1. **You ask it before you ask a person.** Including about your own business, and including things you technically know, because the answer comes back with sources.
2. **You stop opening tabs.** The first move when something lands stops being "open six things" and starts being "ask the system." Quiet, and it compounds.
3. **You stop trying to remember.** You do not rehearse what you decided last quarter or what the client said in March, because retrieval is reliable. The system holds the facts, you hold the questions.
4. **Your `git log` gets long.** The most honest measure in the kit. Every commit is your system learning something. A month of commits is a month of compounding; an empty log is a tool you installed and abandoned.

---

## The one-line version

> Capture what you think, decide what you commit to, compound what stays true, refresh what you act on. Automate only what repeats, holds its shape, and can break loudly.
